const express = require("express");
const Anthropic = require("@anthropic-ai/sdk");
const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));
const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
app.post("/api/chat", async (req, res) => {
  try {
    const messages = req.body.messages;
    if (!Array.isArray(messages)) return res.status(400).json({ error: "messages must be an array" });
    const result = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 4096,
      system: "أنت مساعد برمجة يتحدث العربية. افهم الأخطاء الإملائية واكتب كوداً عملياً مع شرح عربي مختصر.",
      messages
    });
    res.json({ content: result.content });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: "تعذر إكمال الطلب. تحقق من إعدادات API والمفتاح." });
  }
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server listening on ${port}`));
