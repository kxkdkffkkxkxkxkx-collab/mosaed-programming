مساعد البرمجة - نسخة جاهزة للنشر بخادم يحمي مفتاح API

1) ارفع محتويات هذا المجلد إلى مستودع GitHub جديد.
2) انشر المستودع كخدمة Web Service على Render.
3) Build Command: npm install
4) Start Command: npm start
5) من Environment Variables أضف ANTHROPIC_API_KEY وضع مفتاحك هناك، لا داخل الملفات.
6) افتح رابط الموقع الذي يعطيك Render.

ملاحظة: استخدام Anthropic API قد يتطلب رصيداً/فوترة مفعّلة. لا تضع المفتاح في ملفات عامة.
